//Validation of Hot dog name from client side


let warnings = {
    required:"Please enter hot dog name",
    taken:"This name is already taken"
}


let fieldName = document.getElementById('name')

fieldName.addEventListener('blur', isField)
fieldName.addEventListener('blur', nameIsTaken)

function isField(){
    if (fieldName.value == ""){
        warn('required')
    }else{
        unwarn('required')
    }
}

function nameIsTaken(){
    requestTaken = new XMLHttpRequest()

     if (requestTaken == null){

       alert("Unable to create request")
       return}

    let url = "/check"
    let data = "name=" + fieldName.value

   requestTaken.open("POST", url, true);
   requestTaken.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded')

   if(fieldName.value != ""){
   requestTaken.send(data);
   }

    requestTaken.onreadystatechange = ()=>{
        if (requestTaken.readyState == 4){
           if(requestTaken.status == 200){
               if(requestTaken.responseText == 1){

            warn('taken')

            }else{

            unwarn('taken')

            }

}

}
}
}


function warn(warningType){


    let parentNode = fieldName.parentNode
    let warning =eval('warnings.' + warningType)

    if (parentNode.getElementsByTagName('p').length ==0){
        let p = document.createElement('p');
        p.style.color = 'red'
        p.style.fontStyle = 'italic'
        let warningNode = document.createTextNode(warning)
        p.appendChild(warningNode)
        parentNode.appendChild(p)
    }else{
        let p = parentNode.getElementsByTagName('p')[0]
        p.childNodes[0].nodeValue = warning
    }

    document.getElementById('create-button').disabled=true
}




function unwarn(warningType){


     let parentNode = fieldName.parentNode
     let warning = eval('warnings.'+ warningType)

     if(parentNode.getElementsByTagName('p').length > 0){
         let currentWarn = parentNode.getElementsByTagName('p')[0].childNodes[0].nodeValue

         if(currentWarn == warning){

             let p = parentNode.getElementsByTagName('p')[0]
             parentNode.removeChild(p)

             document.getElementById('create-button').disabled=false;
         }
     }

}