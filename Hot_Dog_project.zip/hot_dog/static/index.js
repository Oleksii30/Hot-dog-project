
// Here was delete block RIP


//Update block

let arrows = document.getElementsByClassName('right');
let slide = document.getElementsByClassName('update-form');


for (let i=0; i<arrows.length;i++){
arrows[i].addEventListener('click',e =>{
     if (e.target.className == 'right'){
    slide[i].style.visibility = 'visible';
    e.target.className = 'left';
    }else{
         slide[i].style.visibility = 'hidden';
         e.target.className = 'right';

    }

})
}