from cs50 import SQL
from flask import Flask, flash, jsonify, redirect, render_template, request
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from helpers import apology



# Configure application
app = Flask(__name__)


# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///hot_dog.db")



@app.route("/")
def index():
    rows = db.execute("SELECT * FROM hot_dogs")

    return render_template("index.html", rows=rows)


@app.route("/create", methods=["POST"])
def create():
    if not request.form.get("name"):
            return apology("Must provide hot dog name")

    name = request.form.get("name")
    row = db.execute("SELECT * FROM hot_dogs WHERE name=:name", name = name)
    if row:
        return apology("This name is already taken")

    sausage = request.form.get("sausage")
    quantity = request.form.get("quantity")
    corn = request.form.get("corn")
    catchup = request.form.get("catchup")
    mayonnaise = request.form.get("mayonnaise")
    mustard = request.form.get("mustard")

    db.execute("INSERT INTO hot_dogs (name, sausage_type, quantity, corn, catchup,mayonnaise,mustard) VALUES (:name, :sausage_type, :quantity, :corn, :catchup,:mayonnaise,:mustard)",
                name=name, sausage_type=sausage, quantity=quantity, corn=corn, catchup=catchup,mayonnaise=mayonnaise,mustard=mustard)

    return redirect("/")



@app.route("/delete", methods=["POST"])
def delete():

    name = request.form.get("name")

    db.execute("DELETE FROM hot_dogs WHERE name = :name", name = name)

    return redirect("/")


@app.route("/update", methods=["POST"])
def update():

    name = request.form.get("name")
    new_name = request.form.get("new_name")
    sausage = request.form.get("sausage")
    quantity = request.form.get("quantity")
    corn = request.form.get("corn")
    catchup = request.form.get("catchup")
    mayonnaise = request.form.get("mayonnaise")
    mustard = request.form.get("mustard")

    db.execute("UPDATE hot_dogs SET sausage_type = :sausage, quantity = :quantity, corn = :corn, catchup = :catchup, mayonnaise = :mayonnaise, mustard = :mustard WHERE name = :name",
    name = name, sausage = sausage, quantity = quantity, corn = corn, catchup = catchup, mayonnaise = mayonnaise, mustard = mustard)

    if new_name:
        db.execute("UPDATE hot_dogs SET name = :new_name WHERE name = :name", new_name = new_name, name = name)


    return redirect("/")


@app.route("/check", methods=["POST"])

def check():

    name = request.form.get("name")
    row = db.execute("SELECT * FROM hot_dogs WHERE name=:name", name = name)

    if row:
        return jsonify(1)
    else:
        return jsonify(0)

def errorhandler(e):

    if not isinstance(e, HTTPException):
        e = InternalServerError()
    return apology(e.name)


# Listen for errors
for code in default_exceptions:
    app.errorhandler(code)(errorhandler)